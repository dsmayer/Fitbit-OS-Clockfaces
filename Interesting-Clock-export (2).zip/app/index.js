import document from "document";
import clock from "clock";
import { HeartRateSensor } from "heart-rate";

let myDate = document.getElementById("myDate");
let myClock = document.getElementById("myTime");
let myTime = document.getElementById("myTime2");
let myMinutes = document.getElementById("myMinutes");
let myHR = document.getElementById("myMonth")
let myQuote = document.getElementById("myTime3")
clock.granularity = 'seconds';
let days3 = ["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"];
let months = ["Jan", "Feb",  "Mar",  "Apr",  "May",  "Jun",  "Jul",  "Aug",  "Sep",  "Oct",  "Nov", "Dec"];
let hours = ["12 o'clock AM", "1 o'clock AM", "2 o'clock AM", "3 o'clock AM", "4 o'clock AM", "5 o'clock AM", "6 o'clock AM", "7 o'clock AM", "8 o'clock AM","9 o'clock AM" , "10 o'clock AM", "11 o'clock AM","12 o'clock PM", "1 o'clock PM", "2 o'clock PM", "3 o'clock PM", "4 o'clock PM", "5 o'clock PM", "6 o'clock PM", "7 o'clock PM", "8 o'clock PM","9 o'clock PM" , "10 o'clock PM", "11 o'clock PM" ];
let minutes = ["0  minutes after", "1  minutes after", "2  minutes after", "3 minutes  after", "4 minutes after", "5 minutes after", "6 minutes after", "7 minutes after", "8 minutes after", "9 minutes after", "10 minutes after", "11 minutes after", "12 minutes after", "13 minutes after", "14 minutes after", "15 minutes after", "16 minutes after", "17 minutes after", "18 minutes after", "19 minutes after", "20 minutes after", "21 minutes after", "22 minutes after", "23 minutes after", "24 minutes after", "25 minutes after", "26 minutes after", "27 minutes after", "28 minutes after", "29 minutes after", "30 minutes after", "31 minutes after", "32 minutes after", "33 minutes after", "34 minutes after", "35 minutes after", "36 minutes after", "37 minutes after", "38 minutes after", "39 minutes after", "40 minutes after", "41 minutes after", "42 minutes after", "43 minutes after", "44 minutes after", "45 minutes after", "46 minutes after", "47 minutes after", "48 minutes after", "49 minutes after", "50 minutes after", "51 minutes after", "52 minutes after", "53 minutes after", "54 minutes after", "55 minutes after", "56 minutes after", "57 minutes after", "58 minutes after", "59 minutes after",];
let time3 = ["Its midnight!", "Good Early Morning!", "Good Early Morning!", "Good Early Morning!", "Good Early Morning!", "Good Morning!", "Good Morning!", "Good Morning!", "Have a Great Day!" , "Have a Great Day!", "Good Morning, It's almost noon!", "Good Morning, it's almost noon!", "Its Noon. How about a walk?", "Good Afternoon", "Good Afternoon, Enjoying the day?", "Good Afternoon, remember to get your steps in!", "Good Afternoon, It's Tea Time", "Good Evening, it's the end of the day", "Good Evening, it's dinner time", "Good Evening", "Good Evening, Getting Ready For Bed?", "Good Night", "Good Night, its time to go to sleep.", "Seriously! You're still up?!"];



clock.ontick = function(evt)
{ var meridian = 'a';
 var hour = evt.date.getHours();
    myClock.text =  "" + ("0" + hour).slice(-2) + ":" +
                     ("0" + evt.date.getMinutes()).slice(-2) + ":" +
                     ("0" + evt.date.getSeconds()).slice(-2);
   myDate.text =  days3[evt.date.getDay()]
                    + ", " + months[evt.date.getMonth()] 
                    + " " + evt.date.getDate()
                    + " " + evt.date.getFullYear();
   myTime.text = hours[evt.date.getHours()];
 
  myMinutes.text = minutes[evt.date.getMinutes()];
  myQuote. text = time3[evt.date.getHours()];
  
  
  }
//--- Add heart rate monitor. -----------------------------------------------------------------------
var hrm = new HeartRateSensor();

hrm.start();

function refresh_myHR() {
    myHR.text = "Heart Rate: " + hrm.heartRate
    };

setInterval(refresh_myHR, 1000);



    